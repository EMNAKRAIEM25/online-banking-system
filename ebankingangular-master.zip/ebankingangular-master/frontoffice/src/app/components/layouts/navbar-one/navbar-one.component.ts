import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar-one',
  templateUrl: './navbar-one.component.html',
  styleUrls: ['./navbar-one.component.scss']
})
export class NavbarOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
