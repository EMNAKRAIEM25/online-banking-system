import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar-four',
  templateUrl: './navbar-four.component.html',
  styleUrls: ['./navbar-four.component.scss']
})
export class NavbarFourComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
