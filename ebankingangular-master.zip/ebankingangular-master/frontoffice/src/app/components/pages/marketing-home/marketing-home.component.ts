import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marketing-home',
  templateUrl: './marketing-home.component.html',
  styleUrls: ['./marketing-home.component.scss']
})
export class MarketingHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
