import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-startup-home',
  templateUrl: './startup-home.component.html',
  styleUrls: ['./startup-home.component.scss']
})
export class StartupHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
