export class User {
    id:any;
    username:any;
    email:any;
    password:any;
    name:any;
    lastname:any;
    birthday:any;
    gender:any;
    annualIncome:any;
    spendingScore: any;
    creationDate:any;
    verified:any;
    token:any;
    tokenCreationDate:any;
    verificationCode:any;
    roles:any;
    cluster: any;
    saccounts: any;
}
