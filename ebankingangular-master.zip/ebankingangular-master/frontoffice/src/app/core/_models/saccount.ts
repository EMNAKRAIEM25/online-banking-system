export class Saccount {
    id: any;
    rib: any;
    creationDate: any;
    netInvested: any;
    netPortfolioValue: any;
    unrealizedGainsPercentage: any;
    realizedGains: any;
    realizedGainsPercentage: any;

}

