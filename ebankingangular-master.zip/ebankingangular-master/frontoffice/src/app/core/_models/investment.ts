export class Investment {
    id:any;
    stock:any;
    quantity :any;
    netInvested:any;
    currentValue:any;
    netProfit:any;
    netProfitPercentage:any;
    averageBuyPrice:any;
}
