export class Stock {
    symbol:any;
    name :any;
    price:any;
    previousOpen:any;
    previousClose:any;
    high:any;
    low:any;
    volume:any;
}
