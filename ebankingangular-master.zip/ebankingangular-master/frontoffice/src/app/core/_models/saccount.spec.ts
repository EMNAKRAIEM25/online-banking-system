import { Saccount } from './saccount';

describe('Saccount', () => {
  it('should create an instance', () => {
    expect(new Saccount()).toBeTruthy();
  });
});
