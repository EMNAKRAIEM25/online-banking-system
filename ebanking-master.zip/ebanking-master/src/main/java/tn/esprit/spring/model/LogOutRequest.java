package tn.esprit.spring.model;

public class LogOutRequest {
	  private Long userId;

	  public Long getUserId() {
	    return this.userId;
	  }
	}
