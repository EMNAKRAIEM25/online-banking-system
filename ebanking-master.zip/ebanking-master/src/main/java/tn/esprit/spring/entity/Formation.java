package tn.esprit.spring.entity;

public class Formation {

}
