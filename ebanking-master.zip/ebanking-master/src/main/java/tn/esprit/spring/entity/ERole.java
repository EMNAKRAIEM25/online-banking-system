package tn.esprit.spring.entity;

public enum ERole {
ADMIN, CLIENT
}
